# JPA Demo
Object-relational mapping demo, Java Persistence API (JPA)

Instructions to Create the Tables in mySQL
- Edit src/test/java/csc366/jpademo/TableCreation.java with the mysql login information
- Run the following command:

`./gradlew test`
